import { useState, useEffect } from 'react';
import { FiX, FiSearch } from 'react-icons/fi';
import axios from 'axios';

const RegisterModal = ({ onClose }) => {
  const [products, setProducts] = useState([]);
  const [filter, setFilter] = useState('');
  const [quantities, setQuantities] = useState({});
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    axios.get('https://finastorage-c5fncheyeqecf2hp.brazilsouth-01.azurewebsites.net/api/stocks')
      .then(res => setProducts(Array.isArray(res.data) ? res.data : []))
      .catch(err => console.error('Erro ao carregar produtos', err));
  }, []);

  const handleFilterChange = e => setFilter(e.target.value);

  const handleQuantityChange = (id, value) => {
    setQuantities(prev => ({
      ...prev,
      [id]: Math.max(0, Number(value))
    }));
  };

  const handleSubmit = async e => {
    e.preventDefault();
    const toDecrement = products
      .filter(p => quantities[p.id] > 0)
      .map(p => ({ id: p.id, quantity: quantities[p.id] }));

    try {
      await Promise.all(
        toDecrement.map(item =>
          axios.put(
            `https://finastorage-c5fncheyeqecf2hp.brazilsouth-01.azurewebsites.net/api/stocks/${item.id}/decrement`,
            { quantity: item.quantity }
          )
        )
      );
      setSuccess(true);
    } catch (err) {
      console.error('Erro ao registrar baixa', err);
    }
  };

  const filteredProducts = products.filter(p =>
    p.itemName.toLowerCase().includes(filter.toLowerCase()) ||
    p.id.toLowerCase().includes(filter.toLowerCase()) ||
    p.category.name.toLowerCase().includes(filter.toLowerCase())
  );

  const hasSelection = Object.values(quantities).some(q => q > 0);

  return (
    <div className="modal-overlay">
      <div className="modal-content animate-slide-in" style={{ position: 'relative' }}>
        {/* Close Button */}
        <button
          className="modal-close"
          onClick={onClose}
          style={{ position: 'absolute', top: '8px', right: '8px', background: 'none', border: 'none', fontSize: '1.5rem', cursor: 'pointer' }}
        >
          <FiX />
        </button>

        {!success ? (
          <form onSubmit={handleSubmit} className="form-register">
            <h2>Registrar Baixa no Estoque</h2>
            <div className="search-bar">
              <FiSearch />
              <input
                type="text"
                placeholder="Pesquisar por nome, categoria ou ID..."
                value={filter}
                onChange={handleFilterChange}
              />
            </div>

            <div className="product-list">
              {filteredProducts.map(prod => (
                <div key={prod.id} className="product-row">
                  <div className="product-info">
                    <span className="product-name">{prod.itemName}</span>
                    <span className="product-details">
                      {prod.quantity} {prod.unit} disponíveis | Categoria: {prod.category.name} | Local: {prod.location.stockName}
                    </span>
                  </div>
                  <input
                    type="number"
                    min="0"
                    placeholder="0"
                    value={quantities[prod.id] || ''}
                    onChange={e => handleQuantityChange(prod.id, e.target.value)}
                    className="quantity-input"
                  />
                </div>
              ))}
              {filteredProducts.length === 0 && (
                <p className="empty-message">Nenhum produto encontrado.</p>
              )}
            </div>

            <button
              type="submit"
              className="btn btn-primary"
              disabled={!hasSelection}
            >
              Confirmar Baixas
            </button>
          </form>
        ) : (
          <div className="success-message">
            <h3>Baixas registradas com sucesso!</h3>
            <button className="btn btn-primary" onClick={onClose}>
              Fechar
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default RegisterModal;
